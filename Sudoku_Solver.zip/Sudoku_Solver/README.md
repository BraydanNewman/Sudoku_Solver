# Sudoku Solver
Solves Sudoku's

Icon Creator: https://www.flaticon.com/authors/freepik

[Download the executable](https://github.com/BraydanNewman/Sudoku_Solver/raw/master/SudokuSolver.exe)
